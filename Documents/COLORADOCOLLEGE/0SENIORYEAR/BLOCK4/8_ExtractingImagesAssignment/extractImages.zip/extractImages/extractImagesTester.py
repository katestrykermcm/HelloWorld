from extractImages import extractImages


imageExtracter = extractImages()
imageExtracter.openURL()
imageExtracter.findPicData()
imageExtracter.listInfo()
